// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
// import { fstat } from 'fs';
import * as fs from 'fs';
import { stringify } from 'querystring';

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	console.log('Congratulations, your extension "abbrev" is now active!');

	// The command has been defined in the package.json file
	// Now provide the implementation of the command with registerCommand
	// The commandId parameter must match the command field in package.json
	let disposable = vscode.commands.registerCommand('abbrev.makeAbbreviation', () => {
		// The code you place here will be executed every time your command is executed

		const config = require('/Users/hoangduytran/blender_manual/abbrev/config.json');
		var char_table = config.char_table;
		var removing_chars = config.removing_chars;
		var filler_chars = config.filler_char;
		var is_prefix_abbrev = (config.prefix_abbrev > 0);
		var is_prefix_term = (config.prefix_term > 0);
		var is_reverse_term = (config.reverse_term > 0);
		var is_sep_hyphen = (config.sep_hyphen > 0);


		var rm_chars = "";
		var len = rm_char_id_str.length;
		for (var i = 0; i < len; i++) {
			var cc = rm_char_id_str.charAt(i);
			var idex = Number(cc);
			var char = removing_chars[idex - 1];
			rm_chars += char;
		}
		console.log(`rm_chars:${rm_chars}`);

		vscode.window.showInformationMessage(`config:${config}`);
		console.log(`config:${config.char_table}`);
		vscode.window.showInformationMessage(`config:${config}`);
		// Display a message box to the user
		// vscode.window.showInformationMessage('Hello Hoang Duy Tran from abbrev!');
		// const editor = vscode.window.activeTextEditor;
		// if (!editor) {
		// 	vscode.window.showErrorMessage('Editor does not exist!');
		// 	return;
		// }

		// let raw_data = fs.readFile('/Users/hoangduytran/blender_manual/abbrev/config.json', (err, data) => {
		// 	if (err) {
		// 		console.error(err);
		// 		return;
		// 	};
		// 	let cf = JSON.parse(JSON.stringify(data));
		// 	console.log(cf.prefix_abbrev);
		// 	console.log(cf.char_table);
		// 	console.log(cf.removing_chars);
		// 	let is_prefix_abbrev = (cf.prefix_abbrev > 0);
		// 	let char_table = cf.char_table;
		// 	let removing_chars_id = cf.removing_chars;
		// 	vscode.window.showInformationMessage(`cf.prefix_abbrev: ${cf.prefix_abbrev}, cf.char_table: ${cf.char_table}`);
		// });

		// let config_data = JSON.parse(raw_data);
		// console.log(raw_data);

		// const text = editor.document.getText(editor.selection);
		// vscode.window.showInformationMessage(`Selected: ${text}`);
		// vscode.window.showInformationMessage(`config_json: ${config_json}`);
		// tranform text based on the conditions
		// editor.edit(edit => {
		// 	edit.replace(editor.selection, abbrev_text);
		// 	vscode.window.showInformationMessage(`${abbrev_text}`);
		// });
	});

	context.subscriptions.push(disposable);
}

// this method is called when your extension is deactivated
export function deactivate() { }
